const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Open/Create the SQLite database file
const db = new sqlite3.Database('./mediscan.db');

// Initialize the database table
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS patient_vitals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT,
        hr INTEGER,
        spo2 INTEGER,
        temp REAL,
        timestamp TEXT
    )`);
});

/* ------------------- PATIENT ENDPOINT ------------------- */

// Save scan data from the Patient Portal IR Scan button
app.post('/api/sync-vitals', (req, res) => {
    const { email, hr, spo2, temp, timestamp } = req.body;
    const sql = `INSERT INTO patient_vitals (email, hr, spo2, temp, timestamp) VALUES (?, ?, ?, ?, ?)`;
    
    db.run(sql, [email, hr, spo2, temp, timestamp], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Success! Data is in SQL.", id: this.lastID });
    });
});

/* ------------------- ADMIN ENDPOINT ------------------- */

// Fetch the 10 most recent scans for the Admin Triage Queue
app.get('/api/admin-queue', (req, res) => {
    const sql = `SELECT * FROM patient_vitals ORDER BY id DESC LIMIT 10`;
    db.all(sql, [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

/* ------------------- DOCTOR ENDPOINT ------------------- */

// Fetch the absolute latest vitals for a specific assigned patient
app.get('/api/patient-vitals/:email', (req, res) => {
    const patientEmail = req.params.email;
    const sql = `SELECT * FROM patient_vitals WHERE email = ? ORDER BY id DESC LIMIT 1`;
    
    db.get(sql, [patientEmail], (err, row) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!row) return res.status(404).json({ message: "No scan data found." });
        res.json(row);
    });
});

app.listen(3000, () => console.log('SQL Server active on http://localhost:3000'));